let commonIp='https://www.brt.today';

//测试环境
// let commonIp='http://www.aespayment.info'
// let qiniuApi='http://qh3jznuan.hn-bkt.clouddn.com/';

let qiniuApi='http://sida-tj.com/';

let api={
    commApi:commonIp,
    // klineApi:'http://52.78.213.185:8100',
    // klineApi:'http://13.125.88.118:8100',
    klineApi:'http://www.brt-finance.com:8100',

    //测试环境
    // klineApi:'http://ws.aespayment.info:8100',
    qiniuApi:qiniuApi,
};
export default api;