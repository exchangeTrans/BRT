import en from '@/static/lang/en.js';
import cn from '@/static/lang/cn.js';
import kr from '@/static/lang/kr.js';
export default {  
    en,
    cn,
    kr 
}