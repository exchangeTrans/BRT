let recordAmount={
    num:100
};

export default  recordAmount;
